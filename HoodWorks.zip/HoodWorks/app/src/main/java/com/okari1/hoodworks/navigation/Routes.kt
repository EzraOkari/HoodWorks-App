package com.okari1.hoodworks.navigation

const val ROUTE_SPLASH = "SplashScreen"
const val ROUTE_ONBOARDING1 = "Onboarding1"
const val ROUTE_ONBOARDING2 = "Onboarding2"
const val ROUTE_ONBOARDING3 = "Onboarding3"
const val ROUTE_REGISTER = "Register"
const val ROUTE_LOGIN = "Login"
const val ROUTE_HOME = "HomeScreen"
const val ROUTE_CHAT = "ChatSection"
const val ROUTE_NOTIFICATIONS = "Notifications"
