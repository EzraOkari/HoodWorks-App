package com.okari1.hoodworks.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.okari1.hoodworks.ui.screens.onboarding.Onboarding1
import com.okari1.hoodworks.ui.screens.onboarding.Onboarding2
import com.okari1.hoodworks.ui.screens.splash.SplashScreen

@Composable
fun AppNavHost(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
    startDestination: String = ROUTE_SPLASH
) {

    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier
    ) {
        composable(ROUTE_SPLASH) {
            SplashScreen(navController)
        }
        composable(ROUTE_ONBOARDING1) {
            Onboarding1(navController)
        }
        composable(ROUTE_ONBOARDING2) {
            Onboarding2(navController)
        }

    }
}