package com.okari1.hoodworks.ui.screens.onboarding

